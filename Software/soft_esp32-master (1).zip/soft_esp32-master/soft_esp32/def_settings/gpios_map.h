#ifndef GPIOS_MAP_H
#define GPIOS_MAP_H

//#define PIN_USR_LED         2
#define PIN_USR_BTN         34

#define PIN_NIXIE_A1        12
#define PIN_NIXIE_B1        13
#define PIN_NIXIE_C1        32
#define PIN_NIXIE_D1        33
#define PIN_NIXIE_E1        14
#define PIN_NIXIE_A2        5
#define PIN_NIXIE_B2        17
#define PIN_NIXIE_C2        16
#define PIN_NIXIE_D2        4
#define PIN_NIXIE_A3        25
#define PIN_NIXIE_B3        26
#define PIN_NIXIE_C3        27
#define PIN_NIXIE_D3        23
#define PIN_NIXIE_A4        22
#define PIN_NIXIE_B4        21
#define PIN_NIXIE_C4        19
#define PIN_NIXIE_D4        18

#define PIN_I2C_SDA         15
#define PIN_I2C_SCL         2

#endif