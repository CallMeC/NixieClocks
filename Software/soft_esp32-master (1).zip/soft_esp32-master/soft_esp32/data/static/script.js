function init() {
    autoFillTime();

    setTimeout(updateTime, 1000);
}

function updateTime() {
    var dt = new Date(Date.now());

    document.getElementById('ct_hh').innerHTML = dt.getHours().toString().padStart(2, '0');
    document.getElementById('ct_mm').innerHTML = dt.getMinutes().toString().padStart(2, '0');
    document.getElementById('ct_ss').innerHTML = dt.getSeconds().toString().padStart(2, '0');

    setTimeout(updateTime, 1000);
}

function autoFillTime() {
    var dt = new Date(Date.now());

    document.getElementById('set_time_hh').value = dt.getHours().toString().padStart(2, '0');
    document.getElementById('set_time_mm').value = dt.getMinutes().toString().padStart(2, '0');
    document.getElementById('set_time_ss').value = dt.getSeconds().toString().padStart(2, '0');
}

function showModal(name) {
    document.getElementById(name).style.display = "block";
    document.getElementById(name).parentNode.style.display = "block";
}

function closeModal(e) {
    e.parentNode.parentNode.style.display = "none";
    e.parentNode.parentNode.parentNode.style.display = "none";
}

function timeTyped(e) {
    if(e.value.length == 2) {
        switcNext(e);
    }
}

function switcNext(e) {
    var ns = e.nextElementSibling;

    if(ns == null) {
        return;
    }
    
    if(ns.value.length) {
        ns.setSelectionRange(0, e.value.length);
    } else {
        ns.setSelectionRange(0, 0);
    }
    ns.focus();
}

function timeInputKeyPressed(e) {
    console.log(event.key);
    if(event.key == 'Backspace') {
        timeBackSpace(e);
    } else if(event.key == 'ArrowLeft' && e.selectionStart == 0) {
    } else if(event.key == 'ArrowRight') {
    } else if(isNaN(parseInt(event.key)) && event.key.length == 1) {
        event.preventDefault();
    }
}

function switchPrev(e) {
    var ps = e.previousElementSibling;

    if(ps == null) {
        return;
    }

    ps.setSelectionRange(e.value.length - 1, e.value.length - 1);
    ps.focus();
}

function timeBackSpace(e) {
    if(e.value.length == 0) {
        switchPrev(e);
    }
}

function showSettings(e) {
    if(document.getElementById("settings").style.display == "none") {
        document.getElementById("settings").style.display = "block";
        e.innerHTML = "Hide settings";
    } else {
        document.getElementById("settings").style.display = "none";
        e.innerHTML = "Show settings";

        autoFillTime();
    }
}
