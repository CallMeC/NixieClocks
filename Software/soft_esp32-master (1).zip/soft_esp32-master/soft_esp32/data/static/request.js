function setTime() {
    $.ajax({
        type: 'POST',
        url: '/',
        data: {
            'set_time_hh' : $('#set_time_hh').val(),
            'set_time_mm' : $('#set_time_mm').val(),
            'set_time_ss' : $('#set_time_ss').val(),
        },
        success: function(data) {
        },
        dataType: "application/json"
    });
}

function setTimer() {
    $.ajax({
        type: 'POST',
        url: '/',
        data: {
            'set_timer_hh' : $('#set_timer_hh').val(),
            'set_timer_mm' : $('#set_timer_mm').val(),
            'set_timer_ss' : $('#set_timer_ss').val(),
        },
        success: function(data) {
        },
        dataType: "application/json"
    });
}

function changeFormat(format) {
    $.ajax({
        type: 'POST',
        url: '/',
        data: {
            'set_format' : format
        },
        success: function(data) {
        },
        dataType: "application/json"
    });
}

function blinkSeconds(state) {
    $.ajax({
        type: 'POST',
        url: '/',
        data: {
            'set_blink' : state
        },
        success: function(data) {
        },
        dataType: "application/json"
    });
}

function setStopwatch(state) {
    $.ajax({
        type: 'POST',
        url: '/',
        data: {
            'set_hourglass' : state
        },
        success: function(data) {
        },
        dataType: "application/json"
    });
}

function setupWifi() {
    $.ajax({
        type: 'POST',
        url: '/',
        data: {
            'set_wifi_ssid' : $('#wifi_ssid').val(),
            'set_wifi_pwd' : $('#wifi_pwd').val()
        },
        success: function(data) {
        },
        dataType: "application/json"
    });
}

function setSyncNTP(state) {
    $.ajax({
        type: 'POST',
        url: '/',
        data: {
            'set_NTP' : state
        },
        success: function(data) {
        },
        dataType: "application/json"
    });  
}

function getWifiList() {
    $.ajax({
        type: 'POST',
        url: '/',
        data: "scan_wifi",
        success: function(data) {
            $('#wifi_ssid').html('');
            
            data = JSON.parse(data);
            console.log(data);

            for (var ssid in data){
                $('#wifi_ssid').html($('#wifi_ssid').html() + `<option value="${ssid}">${ssid} (${data[ssid]}dB)</option>`)
            }
        }
    });  
}
