#include "main.h"

APMode apmode(callbackPost);
CredStorage credStore;
STAMode stamode(&credStore);
TimeMgr timemgr;
SettingsMgr settings(&timemgr);

WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP);

void IRAM_ATTR USR_BTN_ISR();

void initGPIOS() {
    Nixie::initGPIOS();

    /*pinMode(PIN_USR_LED, OUTPUT);
    digitalWrite(PIN_USR_LED, LOW);*/

    pinMode(PIN_USR_BTN, INPUT_PULLUP);
    attachInterrupt(PIN_USR_BTN, USR_BTN_ISR, FALLING);

    Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);
}

void initTasks() {
    xTaskCreate(task_NTPUpdate,
        "task_NTPUpdate",
        2048,
        NULL,
        1,
        NULL);

    xTaskCreate(task_FSM_UI,
        "task_FSM_UI",
        2048,
        NULL,
        1,
        NULL);

    xTaskCreate(task_FSM_clock,
        "task_FSM_clock",
        2048,
        NULL,
        1,
        NULL);
}

void setup() {
    Serial.begin(115200);

    FSUtils::initSPIFFS();
    settings.load();

    initGPIOS();

    Serial.println("Setting AP (Access Point)");
    apmode.start();

    initTasks();
}

void IRAM_ATTR USR_BTN_ISR() {

}

void loop() {
}

void task_STAConnect(void *pvParameters) {
    Serial.println("### CONNECTING TO STA ###");
    stamode.connect();
    Serial.println("Connected !");

    vTaskDelete(NULL);
}

void task_NTPUpdate(void *pvParameters) {
    static bool connected = false;

    while(1) {
        if(WiFi.status() == WL_CONNECTED) {
            if(!connected) {
                timeClient.begin();
                timeClient.setTimeOffset(3600);

                connected = true;
            }

            while(!timeClient.update()) {
                timeClient.forceUpdate();
            }

            String dt = timeClient.getFormattedDate();
            timemgr.updateTimeNTP(DateTime(dt));
        } else {
            connected = false;
        }

        vTaskDelay(500 / portTICK_PERIOD_MS);
    }
}
