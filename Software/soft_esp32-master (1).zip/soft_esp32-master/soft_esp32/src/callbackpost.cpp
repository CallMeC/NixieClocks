#include "callbackpost.h"

extern APMode apmode;
extern CredStorage credStore;
extern STAMode stamode;
extern SettingsMgr settings;
extern TimeMgr timemgr;

String callbackPost(String name, String value, AsyncWebServerRequest *request) {
    if(name == "set_blink") {
        settings.setBlink(value == "true");
    }  else if(name == "set_NTP") {
        settings.setSyncNTP(value == "true");
    } else if(name == "body" && value == "scan_wifi") {
        return apmode.getWiFiListJSON();
    } else if(name == "set_wifi_ssid") {
        credStore.storeSSID(value);
    } else if(name == "set_wifi_pwd") {
        credStore.storePwd(value);

        xTaskCreate(task_STAConnect,
            "task_STAConnect",
            2048,
            NULL,
            1,
            NULL);
    } else if(name == "body" && value == "wifi_connected") {
        return String(WiFi.status() == WL_CONNECTED);
    } else if(name == "set_format") {
        settings.setFormat(value);
    }

    return "OK";
}