#include "app.h"

void task_FSM_UI(void *pvParameters) {
    FSM_t fsm;

    while(1) {
        FSM_run(&fsm, xTaskGetTickCount() * portTICK_PERIOD_MS);
    }
}

void task_FSM_clock(void *pvParameters) {
    FSM_t fsm;

    while(1) {
        FSM_run(&fsm, xTaskGetTickCount() * portTICK_PERIOD_MS);
    }
}
