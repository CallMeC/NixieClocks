#ifndef FSUTILS_H
#define FSUTILS_H

#include "SPIFFS.h"

namespace FSUtils {
    void initSPIFFS();
    String readFile(fs::FS &fs, const char * path);
    void writeFile(fs::FS &fs, const char * path, const char * message);
}

#endif