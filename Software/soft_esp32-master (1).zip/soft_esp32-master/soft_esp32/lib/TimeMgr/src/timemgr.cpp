#include <timemgr.h>

TimeMgr::TimeMgr() {
}

TimeMgr::~TimeMgr() {
}

TimeMgr::TimeMgrSource_t TimeMgr::getSource() const {
    return m_source;
}

void TimeMgr::setSource(TimeMgr::TimeMgrSource_t source) {
    m_source = source;
}

TimeMgr::TimeFormat_t TimeMgr::getFormat() const {
    return m_format;
}

void TimeMgr::setFormat(TimeMgr::TimeFormat_t f) {
    m_format = f;
}

DateTime TimeMgr::currentTime() const {
    switch (m_source) {
    case TimeMgr::SOURCE_RTC:
        return m_timeRTC;
        break;
    case TimeMgr::SOURCE_NTP:
        return m_timeNTP;
        break;
    default:
        return DateTime();
        break;
    }
}

DateTime TimeMgr::currentTime12_24() const {
    DateTime dt = currentTime();
    DateTime t;

    switch (m_format) {
    case TimeMgr::FORMAT_12H:
        t = dt;

        if(t.hh != 12) {
            t.hh = t.hh % 12;
        }
        break;
    case TimeMgr::FORMAT_24H:
        t = dt;
        break;
    }

    return t;
}

void TimeMgr::updateTimeRTC(DateTime dt) {
    m_timeRTC = dt;
}

void TimeMgr::updateTimeNTP(DateTime dt) {
    m_timeNTP = dt;
}
