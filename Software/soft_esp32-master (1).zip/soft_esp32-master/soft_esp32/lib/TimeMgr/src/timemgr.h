#ifndef TIMEMGR_H
#define TIMEMGR_H

#include <Arduino.h>

class DateTime {
public:
    DateTime() {}
    DateTime(String s) {
        *this = fromString(s);
    }

    inline static DateTime fromString(String s) {
        s[4] = '\0';
        s[7] = '\0';
        s[10] = '\0';
        s[13] = '\0';
        s[16] = '\0';
        s[19] = '\0';

        DateTime dt;

        dt.YYYY = String(&s[0]).toInt();
        dt.MM = String(&s[5]).toInt();
        dt.DD = String(&s[8]).toInt();
        dt.hh = String(&s[11]).toInt();
        dt.mm = String(&s[14]).toInt();
        dt.ss = String(&s[17]).toInt();

        return dt;
    }

    String toString() const {
        return String(YYYY) + "-" + String(MM) + "-" + String(DD) + " " + 
                String(hh) + ":" + String(mm) + ":" + String(ss);
    }

public :
    uint16_t YYYY = 0;
    uint8_t MM = 0;
    uint8_t DD = 0;
    uint8_t hh = 0;
    uint8_t mm = 0;
    uint8_t ss = 0;
};

class TimeMgr
{
public:
    typedef enum {
        SOURCE_RTC,
        SOURCE_NTP
    } TimeMgrSource_t;

    typedef enum {
        FORMAT_12H,
        FORMAT_24H
    } TimeFormat_t;

public:
    TimeMgr();
    ~TimeMgr();

    TimeMgrSource_t getSource() const;
    void setSource(TimeMgrSource_t source);

    TimeFormat_t getFormat() const;
    void setFormat(TimeFormat_t f);

    DateTime currentTime() const;
    DateTime currentTime12_24() const;

    void updateTimeRTC(DateTime dt);
    void updateTimeNTP(DateTime dt);

private:
    TimeFormat_t m_format = FORMAT_24H;
    TimeMgrSource_t m_source = SOURCE_RTC;
    DateTime m_timeRTC;
    DateTime m_timeNTP;
};

#endif