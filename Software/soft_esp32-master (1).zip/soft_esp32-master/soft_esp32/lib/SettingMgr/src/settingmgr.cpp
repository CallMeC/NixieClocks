#include <settingsmgr.h>

SettingsMgr::SettingsMgr(TimeMgr *timeMgr)
    : m_timeMgr(timeMgr) {

}

SettingsMgr::~SettingsMgr() {

}

void SettingsMgr::load() {
    // TODO : Load Settings
}

bool SettingsMgr::syncNTP() const {
    return m_syncNTP;
}

void SettingsMgr::setSyncNTP(bool en) {
    m_syncNTP = en;

    m_timeMgr->setSource(
        (m_syncNTP)?TimeMgr::SOURCE_NTP:TimeMgr::SOURCE_RTC
    );
}

bool SettingsMgr::blink() const {
    return m_blink;
}

void SettingsMgr::setBlink(bool en) {
    m_blink = en;
}

String SettingsMgr::format() const {
    return m_format;
}

void SettingsMgr::setFormat(String f) {
    m_format = f;

    m_timeMgr->setFormat(
        (m_format == "12H")?TimeMgr::FORMAT_12H:TimeMgr::FORMAT_24H
    );
}
