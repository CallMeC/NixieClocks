#ifndef SETTINGSMGR_H
#define SETTINGSMGR_H

#include <timemgr.h>

class SettingsMgr {
public:
    SettingsMgr(TimeMgr *timeMgr);
    ~SettingsMgr();

    void load();

    bool syncNTP() const;
    void setSyncNTP(bool en);

    bool blink() const;
    void setBlink(bool en);

    String format() const;
    void setFormat(String f);

private :
    TimeMgr *m_timeMgr = nullptr;

private:
    bool m_syncNTP = false;
    bool m_blink = false;
    String m_format;
};

#endif
