#include "apmode.h"

APMode::APMode(
    String (*_callbackPost)(String name, String value, AsyncWebServerRequest *request),
    String APName
    ) : m_callbackPost(_callbackPost), m_APName(APName) {
}   

APMode::~APMode() {
    stop();
}

String APMode::getAPName() const {
    return m_APName;
}

void APMode::setAPName(String APName) {
    m_APName = APName;
}

void APMode::start() {
    if(m_server) {
        return;
    }

    m_server = new AsyncWebServer(80);

    WiFi.disconnect();
    delay(100);
    WiFi.mode(WIFI_AP_STA); // Access Point mode + STA for scanning
    delay(100);
    WiFi.softAP(m_APName.c_str(), NULL);
    delay(100);
    
    scanWiFi();

    IPAddress IP = WiFi.softAPIP();
    Serial.print("AP IP address: ");
    Serial.println(IP);

    initParser(m_server);

    // Web Server Root URL
    m_server->on("/", HTTP_GET, [](AsyncWebServerRequest *request){
        request->send(SPIFFS, "/static/index.html", "text/html");
    });
    
    m_server->serveStatic("/", SPIFFS, "/static/");

    m_server->onNotFound([](AsyncWebServerRequest *request){
        request->send(404);
    });
    
    m_server->begin();
}

void APMode::stop() {
    if(m_server) {
        m_server->end();

        delete m_server;
        m_server = nullptr;
    }
}

void APMode::scanWiFi() {

    //Serial.println("### START SCAN ###");
    int n = WiFi.scanNetworks();
    
    String list = "{";

    for(int i = 0; i < n; i ++) {
        list += ("\"" + WiFi.SSID(i) + "\":" + WiFi.RSSI(i));
        
        if(i < n - 1) {
            list += ", ";
        }
    }

    WiFi.scanDelete();

    list += "}";

    //Serial.println("###  END SCAN  ###");

    m_scanReady = false;
    m_WiFiList = list;
    m_scanReady = true;
}

String APMode::getWiFiListJSON() const {
    while(!m_scanReady);

    return m_WiFiList;
}

void APMode::initParser(AsyncWebServer *server) {
    server->on("/", HTTP_POST, [this](AsyncWebServerRequest *request) {
        int params = request->params();

        for(int i = 0; i < params; i ++) {
            AsyncWebParameter* p = request->getParam(i);

            if(p->isPost()) {
                Serial.printf("POST[%s]: %s\n", p->name().c_str(), p->value().c_str());

                String res = this->m_callbackPost(p->name(), p->value(), request);

                if(res != "") {
                    request->send(200, "text/plain", res);
                }
            }
        }
    });
}
