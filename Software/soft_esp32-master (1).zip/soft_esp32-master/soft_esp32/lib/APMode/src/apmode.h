#ifndef APMODE_H
#define APMODE_H

#include <Arduino.h>
#include <WiFi.h>
#include <ESPAsyncWebServer.h>
#include <AsyncTCP.h>

#include <credstorage.h>

class APMode
{
public:
    APMode(String (*_callbackPost)(String name, String value, AsyncWebServerRequest *request), String APName = "NIXIE-CLOCK");
    ~APMode();

    void start();
    void stop();
    void scanWiFi();
    String getWiFiListJSON() const;
    String (*m_callbackPost)(String name, String value, AsyncWebServerRequest *request) = nullptr;
    String getAPName() const;
    void setAPName(String APName);

private :
    void initParser(AsyncWebServer *server);

private:
    String m_APName;
    String m_WiFiList;
    bool m_scanReady = true;
    AsyncWebServer *m_server = nullptr;
};

#endif