#include <credstorage.h>

CredStorage::CredStorage() {
}

CredStorage::~CredStorage() {
}

String CredStorage::getSSID() const {
    return m_ssid;
}

String CredStorage::getPwd() const {
    return m_pwd;
}

void CredStorage::storeSSID(String ssid) {
    m_ssid = ssid;
}

void CredStorage::storePwd(String pwd) {
    m_pwd = pwd;
}
