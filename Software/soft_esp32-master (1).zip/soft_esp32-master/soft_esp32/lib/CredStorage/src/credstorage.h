#ifndef CREDSTORAGE_H
#define CREDSTORAGE_H

#include <fsutils.h>

class CredStorage
{
public:
    CredStorage();
    ~CredStorage();

    String getSSID() const;
    String getPwd() const;

    void storeSSID(String ssid);
    void storePwd(String pwd);

private:
    String m_ssid;
    String m_pwd;
};

#endif