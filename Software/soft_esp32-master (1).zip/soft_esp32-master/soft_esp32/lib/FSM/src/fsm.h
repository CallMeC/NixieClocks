#ifndef FSM_H
#define FSM_H

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>

typedef struct FSM_Transition_t FSM_Transition_t;

typedef struct
{
    uint32_t startT;

    void (*entryState)(void);
    void (*doState)(uint32_t);
    void (*exitState)(uint32_t);

    size_t Ntrans;
    FSM_Transition_t *transitions;
} FSM_State_t;

struct FSM_Transition_t {
    bool inv;
    bool (*condition)(uint32_t);
    FSM_State_t *nextState;
};

typedef struct {
    FSM_State_t *state;
} FSM_t;

void FSM_init(FSM_t *fsm, FSM_State_t *start, uint32_t t);
void FSM_run(FSM_t *fsm, uint32_t t);

#endif // FSM_H