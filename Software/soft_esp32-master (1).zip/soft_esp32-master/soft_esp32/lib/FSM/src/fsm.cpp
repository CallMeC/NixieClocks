#include <fsm.h>

static void FSM_trans(FSM_t *fsm, uint32_t t);
static void FSM_next(FSM_t *fsm, FSM_State_t *next, uint32_t t);
static void FSM_enterNext(FSM_t *fsm, FSM_State_t *next, uint32_t t);

void FSM_init(FSM_t *fsm, FSM_State_t *start, uint32_t t) {
    FSM_enterNext(fsm, start, t);
}

void FSM_run(FSM_t *fsm, uint32_t t) {
    if(!fsm->state) {
        return;
    }

    if(fsm->state->doState) {
            fsm->state->doState(t - fsm->state->startT);
    }

    FSM_trans(fsm, t);
}

void FSM_trans(FSM_t *fsm, uint32_t t) {
    for(size_t i = 0; i < fsm->state->Ntrans; i ++) {

        FSM_Transition_t *trans = &fsm->state->transitions[i];
        bool (*cond)(uint32_t) = trans->condition;

        FSM_State_t *nextState = NULL;

        if(!cond) {
            nextState = trans->nextState;
        } else {
            bool condRes = cond(t - fsm->state->startT);
            
            if((!trans->inv && condRes) || (trans->inv && !condRes)) {
                nextState = trans->nextState;
            }
        }

        if(nextState) {
            FSM_next(fsm, nextState, t);

            return;
        }

    }
}

static void FSM_next(FSM_t *fsm, FSM_State_t *next, uint32_t t) {
    if(!next || !fsm->state) {
        return;
    }

    if(fsm->state->exitState) {
        fsm->state->exitState(t - fsm->state->startT);
    }

    FSM_enterNext(fsm, next, t);
}

void FSM_enterNext(FSM_t *fsm, FSM_State_t *next, uint32_t t) {
    fsm->state = next;
    
    fsm->state->startT = t;

    if(fsm->state->entryState) {
        fsm->state->entryState();
    }
}
