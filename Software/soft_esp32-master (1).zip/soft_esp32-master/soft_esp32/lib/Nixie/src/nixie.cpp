#include <nixie.h>

Nixie::Nixie() {
}

Nixie::~Nixie() {
}

void Nixie::initGPIOS() {
    pinMode(PIN_NIXIE_A1, OUTPUT);
    pinMode(PIN_NIXIE_B1, OUTPUT);
    pinMode(PIN_NIXIE_C1, OUTPUT);
    pinMode(PIN_NIXIE_D1, OUTPUT);
    pinMode(PIN_NIXIE_E1, OUTPUT);

    pinMode(PIN_NIXIE_A2, OUTPUT);
    pinMode(PIN_NIXIE_B2, OUTPUT);
    pinMode(PIN_NIXIE_C2, OUTPUT);
    pinMode(PIN_NIXIE_D2, OUTPUT);

    pinMode(PIN_NIXIE_A3, OUTPUT);
    pinMode(PIN_NIXIE_B3, OUTPUT);
    pinMode(PIN_NIXIE_C3, OUTPUT);
    pinMode(PIN_NIXIE_D3, OUTPUT);

    pinMode(PIN_NIXIE_A4, OUTPUT);
    pinMode(PIN_NIXIE_B4, OUTPUT);
    pinMode(PIN_NIXIE_C4, OUTPUT);
    pinMode(PIN_NIXIE_D4, OUTPUT);
}

void Nixie::drivePin(uint8_t p, uint8_t v) {
#if DBG_LVL > 1
    Serial.printf("Nixie:Pin[%d]=%hu\n", p, (v!=0));
#endif

    digitalWrite(p, v);
}

void Nixie::displayDigit(Nixie::Nixie_Digit_t d, uint8_t v) {
#if DBG_LVL > 0
    Serial.printf("Nixie:Digit[%d]=%hu\n", d, v);
#endif

    switch (d) {
    case Nixie_Digit_1:
        drivePin(PIN_NIXIE_A1, (v & 0x01));
        drivePin(PIN_NIXIE_B1, (v & 0x02));
        drivePin(PIN_NIXIE_C1, (v & 0x04));
        drivePin(PIN_NIXIE_D1, (v & 0x08));
        break;
    case Nixie_Digit_2:
        drivePin(PIN_NIXIE_A2, (v & 0x01));
        drivePin(PIN_NIXIE_B2, (v & 0x02));
        drivePin(PIN_NIXIE_C2, (v & 0x04));
        drivePin(PIN_NIXIE_D2, (v & 0x08));
        break;
    case Nixie_Digit_3:
        drivePin(PIN_NIXIE_A3, (v & 0x01));
        drivePin(PIN_NIXIE_B3, (v & 0x02));
        drivePin(PIN_NIXIE_C3, (v & 0x04));
        drivePin(PIN_NIXIE_D3, (v & 0x08));
        break;
    case Nixie_Digit_4:
        drivePin(PIN_NIXIE_A4, (v & 0x01));
        drivePin(PIN_NIXIE_B4, (v & 0x02));
        drivePin(PIN_NIXIE_C4, (v & 0x04));
        drivePin(PIN_NIXIE_D4, (v & 0x08));
        break;
    }
}

void Nixie::displayTime(const DateTime &dt) {
    uint8_t hh = dt.hh;
    uint8_t mm = dt.mm;

    displayDigit(Nixie::Nixie_Digit_1, hh / 10);
    displayDigit(Nixie::Nixie_Digit_2, hh % 10);
    displayDigit(Nixie::Nixie_Digit_3, mm / 10);
    displayDigit(Nixie::Nixie_Digit_4, mm % 10);
}

void Nixie::switchOffDigit(Nixie_Digit_t d) {
    displayDigit(d, 0x0A);
}

void Nixie::switchOffAll() {
    switchOffDigit(Nixie::Nixie_Digit_1);
    switchOffDigit(Nixie::Nixie_Digit_2);
    switchOffDigit(Nixie::Nixie_Digit_3);
    switchOffDigit(Nixie::Nixie_Digit_4);
}
