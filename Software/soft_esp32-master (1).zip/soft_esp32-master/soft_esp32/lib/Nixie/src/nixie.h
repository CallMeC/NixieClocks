#ifndef NIXIE_H
#define NIXIE_H

#include <Arduino.h>

#include <gpios_map.h>
#include <timemgr.h>

#define DBG_LVL     2

class Nixie {
public:
    typedef enum {
        Nixie_Digit_1,
        Nixie_Digit_2,
        Nixie_Digit_3,
        Nixie_Digit_4
    } Nixie_Digit_t;

public :
    Nixie();
    ~Nixie();

    static void initGPIOS();
    static void displayDigit(Nixie_Digit_t d, uint8_t v);
    static void displayTime(const DateTime &dt);
    static void switchOffDigit(Nixie_Digit_t d);
    static void switchOffAll();

private :
    static inline void drivePin(uint8_t p, uint8_t v);

};

#endif