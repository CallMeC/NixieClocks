#include <stamode.h>

STAMode::STAMode(CredStorage *credStore)
    : m_credStore(credStore) {
}

STAMode::~STAMode() {
}

void STAMode::connect() {
    WiFi.disconnect();
    delay(100);
    WiFi.begin(m_credStore->getSSID().c_str(), m_credStore->getPwd().c_str());

    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.println("Connecting to WiFi..");
    }
}
