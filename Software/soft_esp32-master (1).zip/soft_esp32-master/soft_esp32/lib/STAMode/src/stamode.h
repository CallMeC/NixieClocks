#ifndef STAMODE_H
#define STAMODE_H

#include <Arduino.h>
#include <WiFi.h>
#include <ESPAsyncWebServer.h>
#include <AsyncTCP.h>

#include <credstorage.h>

class STAMode
{
public:
    STAMode(CredStorage *credStore);
    ~STAMode();

    void connect();

private:
    CredStorage *m_credStore;
};

#endif