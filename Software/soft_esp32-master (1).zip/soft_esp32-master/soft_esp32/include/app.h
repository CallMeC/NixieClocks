#include <apmode.h>
#include <stamode.h>
#include <credstorage.h>
#include <fsutils.h>
#include <settingsmgr.h>

#include <NTPClient.h>
#include <WiFiUdp.h>

#include <fsm.h>

void task_FSM_UI(void *pvParameters);
void task_FSM_clock(void *pvParameters);
