#ifndef CALLBACKPOST_H
#define CALLBACKPOST_H

#include "main.h"

String callbackPost(String name, String value, AsyncWebServerRequest *request);

#endif