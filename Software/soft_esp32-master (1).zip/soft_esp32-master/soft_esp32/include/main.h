#ifndef MAIN_H
#define MAIN_H

#include <Wire.h>

#include <apmode.h>
#include <stamode.h>
#include <credstorage.h>
#include <fsutils.h>
#include <settingsmgr.h>
#include <timemgr.h>
#include <nixie.h>

#include <NTPClient.h>
#include <WiFiUdp.h>

#include "gpios_map.h"
#include "app.h"
#include "callbackpost.h"

//#include "FreeRTOS.h"
//#include "task.h"

void task_STAConnect(void *pvParameters);
void task_NTPUpdate(void *pvParameters);

void initGPIOS();
void initTasks();

#endif